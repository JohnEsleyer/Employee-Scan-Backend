<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'Your Application')); ?></title>
    <!-- Include your CSS stylesheets and JavaScript files here -->
    <!-- <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>"> -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
</head>
<body>
    <!-- Your navigation bar or header section -->
    <header>
        <!-- Place your logo, navigation links, etc. here -->
    </header>

    <!-- The main content of each page -->
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Your footer section -->
    <footer>
        <!-- Place your footer content here -->
    </footer>

    <!-- Include your JavaScript files here -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH /home/john/Documents/Employee-Scan-Backend/resources/views/layouts/app.blade.php ENDPATH**/ ?>